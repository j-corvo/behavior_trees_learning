#ifndef __BATERRY_INTERFACE_H_
#define __BATTERY_INTERFACE_H_

#include "behaviortree_cpp_v3/action_node.h"

class BatteryInterface
{
  public:
    // Constructor
    BatteryInterface();

    // Destructor
    ~BatteryInterface();

    BT::NodeStatus CheckBattery();
};

#endif
