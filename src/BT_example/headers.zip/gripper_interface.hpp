#ifndef __GRIPPER_INTERFACE_H_
#define __GRIPPER_INTERFACE_H_

#include "behaviortree_cpp_v3/action_node.h"

class GripperInterface
{

  public:
    
    // Constructor
    GripperInterface();

    // Destructor
    ~GripperInterface();

    // Methods
    BT::NodeStatus open();
    BT::NodeStatus close();

  private:
    bool open_;
};

#endif